function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let torneiras = [];
let score = 0;
let aguaDesperdicada = 0;
let maxAgua = 100;

function setup() {
  createCanvas(600, 400);
  textFont('Arial');
  spawnTorneira();
}

function draw() {
  background(200, 230, 255);

  // Título
  textSize(20);
  fill(0);
  text("💧 Missão Agrinho 2025 – Feche as torneiras!", 80, 30);

  // Pontuação
  textSize(16);
  text("Pontuação: " + score, 20, 60);
  text("Desperdício: " + nf(aguaDesperdicada, 0, 1) + " litros", 400, 60);

  // Barra de desperdício
  fill(255, 100, 100);
  rect(400, 70, aguaDesperdicada, 20);
  noFill();
  stroke(0);
  rect(400, 70, maxAgua, 20);
  noStroke();

  // Mostrar e atualizar torneiras
  for (let i = torneiras.length - 1; i >= 0; i--) {
    torneiras[i].mostrar();
    torneiras[i].pingar();
    if (torneiras[i].agua >= 20) {
      aguaDesperdicada += 5;
      torneiras.splice(i, 1);
    }
  }

  // Verificar fim de jogo
  if (aguaDesperdicada >= maxAgua) {
    gameOver();
  }

  // A cada 2 segundos, uma nova torneira aparece
  if (frameCount % 120 === 0) {
    spawnTorneira();
  }
}

function mousePressed() {
  for (let i = torneiras.length - 1; i >= 0; i--) {
    if (torneiras[i].clicado(mouseX, mouseY)) {
      score += 10;
      torneiras.splice(i, 1);
    }
  }
}

function spawnTorneira() {
  let x = random(50, width - 50);
  let y = random(100, height - 50);
  torneiras.push(new Torneira(x, y));
}

class Torneira {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.agua = 0;
  }

  mostrar() {
    fill(100, 150, 255);
    ellipse(this.x, this.y, 50);
    fill(0);
    textSize(12);
    text("Fechar", this.x - 20, this.y + 25);
  }

  pingar() {
    this.agua += 0.2;
    fill(0, 100, 255, 100);
    ellipse(this.x, this.y + 40, this.agua);
  }

  clicado(mx, my) {
    return dist(mx, my, this.x, this.y) < 25;
  }
}

function gameOver() {
  noLoop();
  background(50, 50, 100, 200);
  fill(255);
  textSize(36);
  textAlign(CENTER);
  text("💦 Fim de Jogo!", width / 2, height / 2 - 20);
  textSize(20);
  text("Pontuação final: " + score, width / 2, height / 2 + 20);
}
